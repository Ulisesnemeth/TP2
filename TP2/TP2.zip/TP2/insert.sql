
/*SUCURSALES */
INSERT INTO sucursales(Localidad, Cant_Salas)VALUES ('Rosario', 3);
INSERT INTO sucursales(Localidad, Cant_Salas)VALUES ('Córdoba', 3);
INSERT INTO sucursales(Localidad, Cant_Salas)VALUES ('La plata', 3);

/*SALAS*/
INSERT INTO salas(Nro, Cant_Butacas,Id_Sucursal)VALUES (1,20,1);
INSERT INTO salas(Nro, Cant_Butacas,Id_Sucursal)VALUES (2,20,1);
INSERT INTO salas(Nro, Cant_Butacas,Id_Sucursal)VALUES (3,20,1);

INSERT INTO salas(Nro, Cant_Butacas,Id_Sucursal)VALUES (1,20,2);
INSERT INTO salas(Nro, Cant_Butacas,Id_Sucursal)VALUES (2,20,2);
INSERT INTO salas(Nro, Cant_Butacas,Id_Sucursal)VALUES (3,20,2);

INSERT INTO salas(Nro, Cant_Butacas,Id_Sucursal)VALUES (1,20,3);
INSERT INTO salas(Nro, Cant_Butacas,Id_Sucursal)VALUES (2,20,3);
INSERT INTO salas(Nro, Cant_Butacas,Id_Sucursal)VALUES (3,20,3);

/*BUTACAS*/
INSERT INTO butacas(Nro,Id_Salas)VALUES (1,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (2,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (3,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (4,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (5,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (6,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (7,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (8,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (9,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (10,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (11,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (12,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (13,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (14,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (15,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (16,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (17,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (18,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (19,1);
INSERT INTO butacas(Nro,Id_Salas)VALUES (20,1);

INSERT INTO butacas(Nro,Id_Salas)VALUES (1,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (2,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (3,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (4,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (5,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (6,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (7,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (8,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (9,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (10,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (11,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (12,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (13,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (14,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (15,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (16,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (17,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (18,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (19,2);
INSERT INTO butacas(Nro,Id_Salas)VALUES (20,2);

INSERT INTO butacas(Nro,Id_Salas)VALUES (1,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (2,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (3,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (4,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (5,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (6,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (7,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (8,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (9,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (10,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (11,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (12,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (13,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (14,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (15,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (16,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (17,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (18,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (19,3);
INSERT INTO butacas(Nro,Id_Salas)VALUES (20,3);

INSERT INTO butacas(Nro,Id_Salas)VALUES (1,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (2,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (3,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (4,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (5,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (6,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (7,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (8,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (9,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (10,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (11,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (12,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (13,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (14,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (15,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (16,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (17,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (18,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (19,4);
INSERT INTO butacas(Nro,Id_Salas)VALUES (20,4);

INSERT INTO butacas(Nro,Id_Salas)VALUES (1,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (2,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (3,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (4,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (5,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (6,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (7,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (8,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (9,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (10,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (11,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (12,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (13,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (14,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (15,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (16,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (17,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (18,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (19,5);
INSERT INTO butacas(Nro,Id_Salas)VALUES (20,5);

INSERT INTO butacas(Nro,Id_Salas)VALUES (1,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (2,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (3,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (4,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (5,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (6,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (7,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (8,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (9,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (10,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (11,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (12,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (13,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (14,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (15,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (16,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (17,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (18,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (19,6);
INSERT INTO butacas(Nro,Id_Salas)VALUES (20,6);

INSERT INTO butacas(Nro,Id_Salas)VALUES (1,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (2,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (3,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (4,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (5,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (6,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (7,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (8,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (9,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (10,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (11,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (12,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (13,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (14,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (15,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (16,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (17,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (18,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (19,7);
INSERT INTO butacas(Nro,Id_Salas)VALUES (20,7);

INSERT INTO butacas(Nro,Id_Salas)VALUES (1,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (2,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (3,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (4,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (5,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (6,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (7,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (8,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (9,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (10,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (11,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (12,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (13,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (14,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (15,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (16,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (17,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (18,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (19,8);
INSERT INTO butacas(Nro,Id_Salas)VALUES (20,8);

INSERT INTO butacas(Nro,Id_Salas)VALUES (1,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (2,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (3,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (4,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (5,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (6,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (7,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (8,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (9,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (10,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (11,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (12,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (13,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (14,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (15,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (16,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (17,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (18,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (19,9);
INSERT INTO butacas(Nro,Id_Salas)VALUES (20,9);

/*GENERO*/
INSERT INTO genero VALUES ('Ciencia Ficción');
INSERT INTO genero VALUES ('Comedia');
INSERT INTO genero VALUES ('Drama');
INSERT INTO genero VALUES ('Terror');
INSERT INTO genero VALUES ('Romance');
INSERT INTO genero VALUES ('Infantil');


/*PELICULAS*/
INSERT INTO peliculas(Id_Genero,Nombre,ATP,Subtitulado) VALUES(1,'Volver al futuro',1,1);
INSERT INTO peliculas(Id_Genero,Nombre,ATP,Subtitulado) VALUES(2,'Esperando la carroza',1,0);
INSERT INTO peliculas(Id_Genero,Nombre,ATP,Subtitulado) VALUES(3,'Argentina, 1985',1,0);
INSERT INTO peliculas(Id_Genero,Nombre,ATP,Subtitulado) VALUES(1,'El exterminador',1,1);
INSERT INTO peliculas(Id_Genero,Nombre,ATP,Subtitulado) VALUES(4,'El Conjuro 2',0,1);
INSERT INTO peliculas(Id_Genero,Nombre,ATP,Subtitulado) VALUES(3,'Mente indomable',1,1);
INSERT INTO peliculas(Id_Genero,Nombre,ATP,Subtitulado) VALUES(3,'Licorice Pizza',1,1);
INSERT INTO peliculas(Id_Genero,Nombre,ATP,Subtitulado) VALUES(5,'HER',1,1);
INSERT INTO peliculas(Id_Genero,Nombre,ATP,Subtitulado) VALUES(2,'Son como niños',1,1);
INSERT INTO peliculas(Id_Genero,Nombre,ATP,Subtitulado) VALUES(6,'Shrek',1,0);
INSERT INTO peliculas(Id_Genero,Nombre,ATP,Subtitulado) VALUES(6,'La era del hielo',1,0);

/*FUNCIONES*/
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-24','16:00:00',8,1);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-24','17:00:00',8,3);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-25','19:00:00',4,9);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-25','18:20:00',2,9);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-26','23:00:00',2,8);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-26','16:00:00',4,8);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-25','18:20:00',2,7);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-26','23:00:00',2,7);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-26','16:00:00',4,5);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-26','16:00:00',4,5);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-24','19:00:00',4,2);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-24','19:00:00',2,3);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-24','23:00:00',2,4);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-24','16:00:00',4,1);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-24','16:00:00',5,1);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-24','16:00:00',6,1);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-24','16:00:00',7,1);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-24','16:00:00',9,1);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-24','16:00:00',6,2);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-24','16:00:00',2,3);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-24','16:00:00',4,3);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-24','16:00:00',5,3);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-24','16:00:00',6,3);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-24','16:00:00',7,3);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-24','16:00:00',1,3);
insert into funciones(Fecha,Horario,Id_Sala,Id_Pelicula) values ('2022-10-24','16:00:00',5,3);

/*COMPRAS*/
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (3.10,12345678,25,1);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,1245678,25,2);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (3.10,12345678,4,21);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,1245678,4,22);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (3.10,12345678,5,23);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,1245678,5,25);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,38126423,7,24);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,43523754,7,31);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,23126413,12,32);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,13,24);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,43523754,20,25);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,23126413,20,63);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,21,72);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,21,73);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,21,74);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,21,75);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,14,71);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,14,72);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,417354230,9 ,74);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,10,72);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,10,74);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,11,72);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,6,72);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,3,75);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,26,90);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,15,90);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,15,91);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,15,93);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,22,90);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,23,103);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,23,104);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,16,109);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,16,110);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,19,108);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,19,107);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,17,120);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,17,121);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,24,120);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,1,140);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,2,141);
insert into compras(Precio,DNI,Id_Funcion,Id_Butaca) values (4.10,41735423,18,170);

/*PLANES*/
insert into planes values ('Gratuito');
insert into planes values ('Premium');
insert into planes values ('Familiar');
select * from planes

/*USUARIOS*/
insert into usuario values ('Ulises','ulisesnemeth@gmail.com','ulisesnemeth','pass1234',1)
insert into usuario values ('Carlos','carlos@gmail.com','carlos','pass12345',2)
insert into usuario values ('Jorge','jorge20@gmail.com','jorgeelmejor','pass1234',3)
insert into usuario values ('Juan','juan52@gmail.com','juancito','pass12345',4)
insert into usuario values ('Javier','javierCABJ@gmail.com','javi_el_mejor','pass1234',5)
insert into usuario values ('Diego','diego521@gmail.com','diegoMaradona','pass12345',6)
insert into usuario values ('Richard','richy@gmail.com','ricardoo','pass1234',7)


/*SUSCRIPCIONES*/

insert into suscripcion values (1,1,1,'2022-12-15',2,600.00)
insert into suscripcion values (1,2,0,'2022-12-19',2,600.00)
insert into suscripcion values (1,3,1,'2022-12-05',2,600.00)
select * from suscripcion

insert into suscripcion values (2,4,1,'2022-12-13',1,00.00)
insert into suscripcion values (1,5,0,'2022-12-20',1,00.00)


insert into suscripcion values (1,6,1,'2022-12-08',3,800.00)
insert into suscripcion values (1,7,0,'2023-01-01',3,800.00)






/*Peliculas Disponibles*/

insert into peliculasdisponibles values (1,2)
insert into peliculasdisponibles values (1,1)
insert into peliculasdisponibles values (1,3)
insert into peliculasdisponibles values (1,4)
insert into peliculasdisponibles values (1,5)
insert into peliculasdisponibles values (1,6)
insert into peliculasdisponibles values (1,7)
insert into peliculasdisponibles values (1,8)
insert into peliculasdisponibles values (1,9)
insert into peliculasdisponibles values (3,10)
insert into peliculasdisponibles values (3,11)

select * from peliculasdisponibles
